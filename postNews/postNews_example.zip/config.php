<?php
return array (
	'apiUrl'	=> 'http://api.66.ru/',
	'apiKey'	=> ''
);